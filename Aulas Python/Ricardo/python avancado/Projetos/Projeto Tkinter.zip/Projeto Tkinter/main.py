from classes.interface import *


def main():
    """
    -> Executa o programa principal.

    Passos:
    1. Mostra os autores do projeto.
    2. Executa a class interface que mostra o display gráfico
    Param:
    None.

    Return:
    None.
    """
    Autores.mostrar_autores()
    Interface()


if __name__ == "__main__":
    main()
